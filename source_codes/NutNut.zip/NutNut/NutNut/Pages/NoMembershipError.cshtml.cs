using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace NutNut.Pages
{
    public class NoMembershipErrorModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
